const STORY_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-3H4z"/><path d="M20 4h-4a3 3 0 0 0-3 3v14a4 4 0 0 1 4-3h3z"/><path d="M7 8h3M7 12h3M16 8h1M16 12h1"/></svg>';
const OUTPUT_OPTIONS = [{ value: "auto", label: "Auto" }, { value: "openai", label: "OpenAI-compatible JSON Schema" }, { value: "anthropic", label: "Anthropic Tool" }, { value: "plain", label: "Plain JSON" }];

export function setup(ctx) {
  const cleanups = [], mounts = [];
  let activeChatId, latestStatus = null, showPrivate = false, disposed = false, dirty = false, widget = null, widgetButton = null;
  let connectionOptions = [{ value: "", label: "Active default connection" }], pendingSetup = null, downloadText = null, cleanupToken = null;
  let routeGeneration = 0, generationBusy = false, lastPrivateRevision = -1;
  const element = (tag, className, text) => { const el = document.createElement(tag); if (className) el.className = className; if (text !== undefined) el.textContent = text; return el; };
  const send = payload => ctx.sendToBackend({ chatId: activeChatId, ...payload });
  const requestStatus = () => send({ type: "story_get_status", includePrivate: showPrivate });
  const removeStyle = ctx.dom.addStyle(`
    .sce-panel{display:grid;gap:16px;color:var(--lumiverse-text);font-size:.85rem}
    .sce-section{display:grid;gap:10px;border-bottom:1px solid var(--lumiverse-border);padding-bottom:14px}
    .sce-heading{font-size:.86rem;font-weight:600;margin:0}.sce-status-row{display:flex;justify-content:space-between;gap:10px}
    .sce-hint{font-size:.73rem;line-height:1.5;color:var(--lumiverse-text-muted);overflow-wrap:anywhere}
    .sce-field{display:grid;gap:6px}.sce-field>label{font-size:.78rem;font-weight:500}.sce-actions{display:flex;gap:8px;flex-wrap:wrap}
    .sce-button{border:1px solid var(--lumiverse-border);border-radius:8px;background:var(--lumiverse-bg-elevated,var(--lumiverse-bg));color:var(--lumiverse-text);padding:8px 10px;cursor:pointer;font:inherit;font-size:.76rem}
    .sce-button:hover{border-color:var(--lumiverse-primary)}.sce-button:disabled{opacity:.45;cursor:default}.sce-primary{background:var(--lumiverse-primary);color:var(--lumiverse-text-on-primary,#fff)}
    .sce-control{box-sizing:border-box;width:100%;background:var(--lumiverse-bg);border:1px solid var(--lumiverse-border);border-radius:7px;color:var(--lumiverse-text);padding:8px;font:inherit}
    .sce-details>summary{cursor:pointer;font-weight:500;font-size:.8rem}.sce-details-body{display:grid;gap:12px;padding-top:12px}
    .sce-check{display:flex;align-items:center;gap:8px}.sce-toggle{display:flex;align-items:center;justify-content:space-between;gap:12px}.sce-record{border:1px solid var(--lumiverse-border);border-radius:9px;padding:12px;display:grid;gap:7px}
    .sce-record h4{margin:0;font-size:.8rem}.sce-row{display:grid;grid-template-columns:100px 1fr;gap:8px;font-size:.76rem;line-height:1.5;overflow-wrap:anywhere}.sce-row dt{color:var(--lumiverse-text-muted)}.sce-row dd{margin:0;white-space:pre-wrap}
    .sce-json{white-space:pre-wrap;overflow-wrap:anywhere;margin:0;font-size:.72rem;line-height:1.5;max-height:550px;overflow:auto}
    .sce-notice{color:var(--lumiverse-warning,#c89b62)}.sce-widget{display:grid;place-items:center;width:40px;height:40px;padding:0;border:0;background:transparent;color:var(--lumiverse-success,#86af92);cursor:pointer;position:relative}
    .sce-widget[data-state="processing"]{color:var(--lumiverse-warning,#c89b62);animation:sce-pulse 1.6s ease-in-out infinite}.sce-widget[data-state="attention"]{color:var(--lumiverse-warning,#c89b62)}
    .sce-widget[data-state="attention"]:after{content:"!";position:absolute;top:0;right:3px;font-weight:700;font-size:12px}@keyframes sce-pulse{50%{opacity:.45}}@media(prefers-reduced-motion:reduce){.sce-widget{animation:none!important}}
    .sce-panel [hidden]{display:none!important}
  `);
  cleanups.push(removeStyle);
  const tab = ctx.ui.registerDrawerTab({ id: "story-continuity", title: "Story Continuity Engine", shortName: "Story Continuity", headerTitle: "Story Continuity",
    description: "Character and world continuity for generic cards", keywords: ["story", "continuity", "NPC", "profile", "world"], iconSvg: STORY_ICON });
  cleanups.push(() => tab.destroy());
  const panel = element("div", "sce-panel"); tab.root.append(panel);
  const section = title => { const root = element("section", "sce-section"); root.append(element("h3", "sce-heading", title)); panel.append(root); return root; };
  const statusSection = section("Story Continuity");
  const statusRow = element("div", "sce-status-row"), statusText = element("div", "", "Checking continuity…"), badgeSlot = element("div");
  const revisionText = element("div", "sce-hint"), cardNotice = element("div", "sce-hint sce-notice");
  cardNotice.hidden = true; statusRow.append(statusText, badgeSlot); statusSection.append(statusRow, revisionText, cardNotice);
  const setupSection = section("Saved setup"), setupActions = element("div", "sce-actions"), setupFeedback = element("div", "sce-hint", "Save the original starting state and private profiles as a reusable JSON file.");
  setupFeedback.setAttribute("aria-live", "polite"); setupSection.append(setupActions, setupFeedback);
  const settings = section("Tracker settings"), settingsHint = element("div", "sce-hint", "Initialize from the character card, then update after completed story turns."); settings.append(settingsHint);
  const advanced = element("details", "sce-details"), advancedBody = element("div", "sce-details-body");
  advanced.append(element("summary", "", "Advanced settings"), advancedBody);
  const field = (root, label, hint) => { const row = element("div", "sce-field"), slot = element("div"); row.append(element("label", "", label), slot); if (hint) row.append(element("div", "sce-hint", hint)); root.append(row); return slot; };
  const native = ["mountSelect", "mountSwitch", "mountCheckbox", "mountNumericInput", "mountBadge"].every(method => typeof ctx.components?.[method] === "function");
  function control(kind, root, label, value, props = {}, onChange = () => { dirty = true; }) {
    const slot = field(root, label, props.hint);
    if (kind === "switch") slot.parentElement.classList.add("sce-toggle");
    if (native) {
      const method = { switch: "mountSwitch", checkbox: "mountCheckbox", select: "mountSelect", number: "mountNumericInput" }[kind];
      const handle = ctx.components[method](slot, { ...props, ...(kind === "switch" || kind === "checkbox" ? { checked: value } : { value }), ariaLabel: label, onChange });
      mounts.push(handle);
      return { get: () => handle.getValue(), set: next => handle.update(kind === "switch" || kind === "checkbox" ? { checked: next } : { value: next }), options: next => handle.update({ options: next }) };
    }
    const input = element(kind === "select" ? "select" : "input", kind === "switch" || kind === "checkbox" ? "" : "sce-control");
    input.setAttribute("aria-label", label);
    if (kind !== "select") input.type = kind === "number" ? "number" : "checkbox";
    if (props.min !== undefined) input.min = props.min;
    if (props.max !== undefined) input.max = props.max;
    if (props.step !== undefined) input.step = props.step;
    const options = entries => { input.replaceChildren(); for (const entry of entries) { const option = element("option", "", entry.label); option.value = entry.value; input.append(option); } };
    if (kind === "select") options(props.options ?? []);
    const set = next => { if (kind === "switch" || kind === "checkbox") input.checked = next; else input.value = next; };
    set(value); input.addEventListener("change", () => onChange(kind === "switch" || kind === "checkbox" ? input.checked : input.value)); slot.append(input);
    return { get: () => kind === "switch" || kind === "checkbox" ? input.checked : kind === "number" ? Number(input.value) : input.value, set, options };
  }
  const enabled = control("switch", settings, "Tracking enabled", true);
  const widgetPreference = control("switch", settings, "Show Widget", true, {}, value => {
    if (latestStatus) latestStatus.config.showStatusWidget = value;
    if (!value) destroyWidget(); else updateWidget(latestStatus);
    send({ type: "story_set_widget_visibility", showStatusWidget: value });
  });
  const connection = control("select", settings, "Tracker connection", "", { options: connectionOptions });
  const connectionHint = element("div", "sce-hint"); settings.append(connectionHint);
  const output = control("select", advancedBody, "Structured output mode", "auto", { options: OUTPUT_OPTIONS });
  const tokens = control("number", advancedBody, "Maximum tracker output tokens", 6144, { min: 400, max: 16384, step: 100, integer: true });
  const timeout = control("number", advancedBody, "Tracker timeout in seconds", 120, { min: 5, max: 300, step: 5, integer: true });
  settings.append(advanced);
  let badge;
  if (native) { badge = ctx.components.mountBadge(badgeSlot, { text: "Checking", color: "neutral", size: "pill" }); mounts.push(badge); }
  else { const text = element("span", "sce-hint", "Checking"); badgeSlot.append(text); badge = { update: props => { text.textContent = props.text; } }; }

  const snapshotSection = section("Continuity snapshot"), snapshotContent = element("div", "sce-field"); snapshotSection.append(snapshotContent);
  const actionSection = section("Actions"), actions = element("div", "sce-actions"), feedback = element("div", "sce-hint"); feedback.setAttribute("aria-live", "polite"); actionSection.append(actions, feedback);
  const privateDetails = element("details", "sce-details"), privateBody = element("div", "sce-details-body"), privateText = element("pre", "sce-json", "Private state is hidden.");
  privateDetails.append(element("summary", "", "Private tracker state"), privateBody); panel.append(privateDetails);
  control("checkbox", privateBody, "Show Private Tracker State", false, { label: "Show private tracker state" }, value => {
    showPrivate = Boolean(value); lastPrivateRevision = -1; privateText.textContent = showPrivate ? "Loading private state…" : "Private state is hidden."; requestStatus();
  }); privateBody.append(privateText);
  const button = (root, text, action, primary = false) => { const btn = element("button", `sce-button${primary ? " sce-primary" : ""}`, text); btn.type = "button"; btn.addEventListener("click", action); root.append(btn); return btn; };
  button(actions, "Save Settings", () => { dirty = false; send({ type: "story_save_config", config: { enabled: enabled.get(), showStatusWidget: widgetPreference.get(), connectionId: connection.get(), outputMode: output.get(), maxTokens: tokens.get(), timeoutMs: Number(timeout.get()) * 1000 } }); }, true);
  button(actions, "Refresh Connections", () => send({ type: "story_get_connections" }));
  const reprocess = button(actions, "Reprocess Latest Turn", () => { feedback.textContent = "Reprocessing latest turn…"; send({ type: "story_reprocess", includePrivate: showPrivate }); });
  const refreshCards = button(actions, "Refresh Card Profiles", () => { feedback.textContent = "Refreshing profiles and reconciling selected history…"; send({ type: "story_refresh_cards", includePrivate: showPrivate }); });
  const cleanupButton = button(actions, "Clean Unused Tracking Files", () => { send(cleanupToken ? { type: "story_cleanup_unused", token: cleanupToken } : { type: "story_scan_cleanup" }); cleanupToken = null; cleanupButton.textContent = "Clean Unused Tracking Files"; });
  const download = button(setupSection, "Download JSON File", () => {
    if (!downloadText) return;
    const url = URL.createObjectURL(new Blob([downloadText], { type: "application/json" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "story-continuity-initial-setup.json";
    document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }, true); download.hidden = true;
  const importButton = button(setupActions, "Import Setup — Choose File", async () => {
    if (pendingSetup) return;
    const route = routeGeneration, chatId = activeChatId;
    setupFeedback.textContent = "Choose a saved story setup…";
    try {
      const files = await ctx.uploads.pickFile({ accept: [".json", "application/json"], multiple: false, maxSizeBytes: 256 * 1024 });
      if (route !== routeGeneration || chatId !== activeChatId || !files?.length) return;
      const fileText = new TextDecoder().decode(files[0].bytes);
      pendingSetup = { id: crypto.randomUUID(), chatId, route };
      send({ type: "story_import_setup", requestId: pendingSetup.id, fileText }); updateButtons();
    } catch (error) { if (route === routeGeneration) setupFeedback.textContent = error.message; }
  });
  const exportButton = button(setupActions, "Export Initial Setup", () => {
    if (pendingSetup) return;
    downloadText = null; download.hidden = true;
    // Open Save As in the original click to retain browser user activation.
    let picker = null;
    if (window.isSecureContext && typeof window.showSaveFilePicker === "function") {
      picker = window.showSaveFilePicker({ suggestedName: "story-continuity-initial-setup.json", types: [{ description: "Story setup", accept: { "application/json": [".json"] } }] });
      picker.catch(() => undefined);
    }
    pendingSetup = { id: crypto.randomUUID(), chatId: activeChatId, route: routeGeneration, picker };
    send({ type: "story_export_setup", requestId: pendingSetup.id }); setupFeedback.textContent = "Preparing original starting state…"; updateButtons();
  });
  const beginButton = button(setupActions, "Begin Story", () => send({ type: "story_begin" }), true); beginButton.hidden = true;
  function updateButtons() {
    importButton.disabled = Boolean(pendingSetup) || generationBusy || !latestStatus?.canImport;
    exportButton.disabled = Boolean(pendingSetup) || !latestStatus?.canExport;
    beginButton.hidden = !latestStatus?.canBegin;
    beginButton.disabled = Boolean(pendingSetup) || generationBusy;
    reprocess.disabled = refreshCards.disabled = !activeChatId || latestStatus?.processing || generationBusy;
  }
  function renderSnapshot(snapshot) {
    snapshotContent.replaceChildren();
    if (!snapshot) { snapshotContent.append(element("div", "sce-hint", "No tracked scene is available yet.")); return; }
    const labels = { date: "Date", time: "Time", weather: "Weather", location: "Location", immediateContext: "Context", proximityAndContact: "Proximity / contact", sceneStatus: "Scene",
      face: "Face", eyes: "Eyes", skin: "Skin", body: "Body", distinguishingFeatures: "Features", hairAndGrooming: "Hair / grooming", dressAndLayers: "Clothing / layers", physicalState: "Condition", position: "Position", activity: "Activity", items: "Items", description: "Description", currentState: "Current state", connections: "Connections" };
    const record = (title, data) => {
      const root = element("div", "sce-record"); root.append(element("h4", "", title));
      for (const [key, value] of Object.entries(data)) if (value && value !== "Unknown") {
        const row = element("dl", "sce-row"); row.style.margin = "0"; row.append(element("dt", "", labels[key] ?? key), element("dd", "", String(value))); root.append(row);
      }
      snapshotContent.append(root);
    };
    record("World and current scene", snapshot.world);
    for (const char of snapshot.characters ?? []) record(`${char.name} · ${char.role === "npc" ? "NPC" : char.role === "user" ? "User character" : "Main character"}`, { ...char.appearance, ...char.visible });
    const names = new Map((snapshot.characters ?? []).map(char => [char.id, char.name]));
    for (const rel of snapshot.relationships ?? []) record(`${names.get(rel.fromId) ?? rel.fromId} → ${names.get(rel.toId) ?? rel.toId}`, { Relationship: rel.publicStatus });
    for (const place of snapshot.places ?? []) record(place.name, { description: place.description, currentState: place.currentState, connections: place.connections });
  }
  function destroyWidget() { if (widget) { try { widget.destroy(); } catch { /* host teardown */ } } widget = widgetButton = null; }
  function updateWidget(status) {
    if (!status?.chatId || !status.snapshot || status.config.showStatusWidget === false) { destroyWidget(); return; }
    if (!widget && typeof ctx.ui.createFloatWidget === "function") {
      try {
        widget = ctx.ui.createFloatWidget({ width: 48, height: 48, initialPosition: { x: 12, y: Math.max(72, Math.round(window.innerHeight * .42)) }, snapToEdge: true, chromeless: true, persistGeometry: "story-continuity-status", tooltip: "Story Continuity" });
        widgetButton = element("button", "sce-widget"); widgetButton.type = "button"; widgetButton.innerHTML = STORY_ICON;
        let start = null, dragged = false;
        widgetButton.addEventListener("pointerdown", event => { start = { x: event.clientX, y: event.clientY }; dragged = false; });
        widgetButton.addEventListener("pointermove", event => { if (start && Math.hypot(event.clientX - start.x, event.clientY - start.y) > 5) dragged = true; });
        widgetButton.addEventListener("click", () => { if (!dragged) tab.activate(); start = null; });
        const stop = widget.onDragEnd?.(() => { dragged = true; }); if (stop) cleanups.push(stop);
        widget.root.append(widgetButton);
      } catch { destroyWidget(); connectionHint.textContent = "Floating widget unavailable; grant UI panels permission to use it."; }
    }
    if (widgetButton) { widgetButton.dataset.state = status.processing ? "processing" : status.level === "green" ? "active" : "attention"; widgetButton.title = status.text; widgetButton.setAttribute("aria-label", status.text); }
  }
  function renderStatus(status) {
    if (disposed || activeChatId !== undefined && status.chatId !== activeChatId) return;
    if (activeChatId === undefined) activeChatId = status.chatId;
    latestStatus = status;
    statusText.textContent = status.text;
    revisionText.textContent = `Revision ${status.revision}${status.lastRevisionAt ? ` · Last revised ${new Date(status.lastRevisionAt).toLocaleString()}` : ""}`;
    badge.update({ text: status.processing ? "Updating" : status.code === "active" ? "Ready" : status.code === "idle" ? "Idle" : "Attention", color: status.level === "green" ? "success" : "warning" });
    tab.setBadge(status.level === "green" || status.code === "idle" ? null : "!");
    if (!dirty) { enabled.set(status.config.enabled); widgetPreference.set(status.config.showStatusWidget); output.set(status.config.outputMode); tokens.set(status.config.maxTokens); timeout.set(status.config.timeoutMs / 1000); connection.options(connectionOptions); connection.set(status.config.connectionId); }
    cardNotice.hidden = !status.cardChanged;
    cardNotice.textContent = "The card changed. Use Refresh Card Profiles to rebuild continuity from the edited card and selected history.";
    renderSnapshot(status.snapshot); updateButtons(); updateWidget(status);
    if (!showPrivate) privateText.textContent = "Private state is hidden.";
    else if (status.privateStateIncluded) { privateText.textContent = status.privateState ? JSON.stringify(status.privateState, null, 2) : "No private state available."; lastPrivateRevision = status.revision; }
    else if (lastPrivateRevision !== status.revision && !status.processing) { privateText.textContent = "Loading current private state…"; requestStatus(); }
  }
  async function handleSetupResult(payload) {
    const pending = pendingSetup;
    if (!pending || payload.requestId !== pending.id || payload.chatId !== activeChatId || pending.route !== routeGeneration) return;
    pendingSetup = null; setupFeedback.textContent = payload.message; updateButtons();
    if (!payload.ok || !payload.fileText) { requestStatus(); return; }
    if (pending.picker) {
      try {
        const handle = await pending.picker;
        if (pending.route !== routeGeneration || disposed) return;
        const writable = await handle.createWritable();
        if (pending.route !== routeGeneration || disposed) { await writable.abort(); return; }
        await writable.write(payload.fileText); await writable.close();
        if (pending.route === routeGeneration) setupFeedback.textContent = "Initial setup saved.";
        return;
      } catch (error) { if (pending.route !== routeGeneration || disposed) return; if (error.name === "AbortError") { setupFeedback.textContent = "Save canceled."; return; } setupFeedback.textContent = `Save failed: ${error.message}. Use Download JSON File.`; }
    }
    if (pending.route === routeGeneration) { downloadText = payload.fileText; download.hidden = false; setupFeedback.textContent = "Setup ready. Select Download JSON File to save it."; }
  }
  function changeChat(chatId) {
    if (chatId === activeChatId) return;
    activeChatId = chatId; routeGeneration++; latestStatus = null; pendingSetup = null; downloadText = null; download.hidden = true;
    generationBusy = false; dirty = false; lastPrivateRevision = -1; cleanupToken = null;
    privateText.textContent = showPrivate ? "Loading private state…" : "Private state is hidden.";
    statusText.textContent = chatId ? "Loading chat continuity…" : "Open a character chat to begin.";
    setupFeedback.textContent = "Save the original starting state and private profiles as a reusable JSON file.";
    renderSnapshot(null); destroyWidget(); updateButtons(); requestStatus();
  }
  cleanups.push(ctx.onBackendMessage(payload => {
    if (payload?.type === "story_status") renderStatus(payload);
    if (payload?.type === "story_connections") {
      connectionOptions = [{ value: "", label: "Active default connection" }, ...(payload.connections ?? []).map(entry => ({ value: entry.id, label: entry.name ?? entry.id }))];
      const current = connection.get(); connection.options(connectionOptions); connection.set(current); connectionHint.textContent = payload.error ?? "";
    }
    if (payload?.type === "story_setup_result") handleSetupResult(payload);
    if (payload?.type === "story_config_saved") { dirty = false; requestStatus(); }
    if (payload?.type === "story_cleanup_scan") { feedback.textContent = payload.message; cleanupToken = payload.count ? payload.token : null; cleanupButton.textContent = cleanupToken ? `Delete ${payload.count} Unused Files` : "Clean Unused Tracking Files"; }
    if (payload?.type === "story_action_result" && (!payload.chatId || payload.chatId === activeChatId)) { feedback.textContent = payload.message; requestStatus(); }
  }));
  cleanups.push(ctx.events.on("CHAT_SWITCHED", payload => changeChat(typeof payload?.chatId === "string" ? payload.chatId : null)));
  for (const name of ["GENERATION_STARTED", "GENERATION_ENDED", "GENERATION_STOPPED"]) cleanups.push(ctx.events.on(name, payload => { if (payload?.chatId === activeChatId) { generationBusy = name === "GENERATION_STARTED"; updateButtons(); } }));
  for (const name of ["MESSAGE_SENT", "MESSAGE_EDITED", "MESSAGE_DELETED", "MESSAGE_SWIPED"]) cleanups.push(ctx.events.on(name, payload => { if (activeChatId && payload?.chatId === activeChatId) requestStatus(); }));
  cleanups.push(tab.onActivate(requestStatus));
  ctx.ready();
  try { if (typeof ctx.getActiveChat === "function") changeChat(ctx.getActiveChat()?.chatId ?? null); else requestStatus(); } catch { requestStatus(); }
  send({ type: "story_get_connections" });
  return () => { disposed = true; routeGeneration++; destroyWidget(); for (const handle of mounts.reverse()) { try { handle.destroy(); } catch { /* host teardown */ } } for (const cleanup of cleanups.reverse()) { try { cleanup(); } catch { /* host teardown */ } } ctx.dom.cleanup(); };
}
